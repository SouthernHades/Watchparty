"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"

const REACTIONS = ["👍", "❤️", "😂", "😮", "🔥", "👎"]

interface Reaction {
  id: string
  emoji: string
  user_id: string
}

interface MessageReactionsProps {
  messageId: string
  userId: string
}

export function MessageReactions({ messageId, userId }: MessageReactionsProps) {
  const supabase = createClient()
  const [reactions, setReactions] = useState<Reaction[]>([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    async function fetchReactions() {
      const { data } = await supabase
        .from("reactions")
        .select("id, emoji, user_id")
        .eq("message_id", messageId)

      if (data) {
        setReactions(data)
      }
    }

    fetchReactions()
  }, [messageId, supabase])

  // Subscribe to reaction changes
  useEffect(() => {
    const channel = supabase
      .channel(`reactions:${messageId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "reactions",
          filter: `message_id=eq.${messageId}`,
        },
        async () => {
          // Refetch reactions on any change
          const { data } = await supabase
            .from("reactions")
            .select("id, emoji, user_id")
            .eq("message_id", messageId)

          if (data) {
            setReactions(data)
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [messageId, supabase])

  async function handleReaction(emoji: string) {
    const existingReaction = reactions.find(
      (r) => r.emoji === emoji && r.user_id === userId
    )

    if (existingReaction) {
      // Remove reaction
      setReactions((prev) => prev.filter((r) => r.id !== existingReaction.id))
      await supabase.from("reactions").delete().eq("id", existingReaction.id)
    } else {
      // Add reaction
      const { data, error } = await supabase
        .from("reactions")
        .insert({
          message_id: messageId,
          user_id: userId,
          emoji,
        })
        .select()
        .single()

      if (!error && data) {
        setReactions((prev) => [...prev, data])
      }
    }

    setIsOpen(false)
  }

  // Group reactions by emoji
  const reactionCounts = reactions.reduce(
    (acc, r) => {
      acc[r.emoji] = (acc[r.emoji] || 0) + 1
      return acc
    },
    {} as Record<string, number>
  )

  const userReactions = reactions
    .filter((r) => r.user_id === userId)
    .map((r) => r.emoji)

  return (
    <div className="flex items-center gap-1 mt-1">
      {Object.entries(reactionCounts).map(([emoji, count]) => (
        <button
          key={emoji}
          onClick={() => handleReaction(emoji)}
          className={cn(
            "flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors",
            userReactions.includes(emoji)
              ? "border-primary bg-primary/10"
              : "border-border hover:border-primary/50"
          )}
        >
          <span>{emoji}</span>
          <span className="text-muted-foreground">{count}</span>
        </button>
      ))}
      
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full">
            <span className="sr-only">Add reaction</span>
            <svg className="h-4 w-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2" side="top">
          <div className="flex gap-1">
            {REACTIONS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => handleReaction(emoji)}
                className={cn(
                  "p-2 rounded hover:bg-muted transition-colors text-lg",
                  userReactions.includes(emoji) && "bg-primary/10"
                )}
              >
                {emoji}
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
