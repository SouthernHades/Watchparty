"use client"

import { formatDistanceToNow } from "date-fns"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  created_at: string
  user_id: string
  profiles: {
    display_name: string
  } | null
}

interface ChatMessageProps {
  message: Message
  isOwn: boolean
  userId: string
}

import { MessageReactions } from "./message-reactions"

export function ChatMessage({ message, isOwn, userId }: ChatMessageProps) {
  const displayName = message.profiles?.display_name || "Anonymous"
  const initials = displayName.slice(0, 2).toUpperCase()
  
  return (
    <div className={cn("flex gap-3", isOwn && "flex-row-reverse")}>
      <div className={cn(
        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-medium",
        isOwn ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
      )}>
        {initials}
      </div>
      <div className={cn("flex flex-col max-w-[70%]", isOwn && "items-end")}>
        <div className="flex items-center gap-2 mb-1">
          <span className={cn(
            "text-sm font-medium",
            isOwn && "order-2"
          )}>
            {displayName}
          </span>
          <span className="text-xs text-muted-foreground">
            {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
          </span>
        </div>
        <div className={cn(
          "rounded-2xl px-4 py-2 text-sm",
          isOwn 
            ? "bg-primary text-primary-foreground rounded-tr-sm" 
            : "bg-muted rounded-tl-sm"
        )}>
          {message.content}
        </div>
        {!message.id.startsWith("temp-") && (
          <MessageReactions messageId={message.id} userId={userId} />
        )}
      </div>
    </div>
  )
}
