"use client"

import { useState, useEffect, useCallback } from "react"
import { createClient } from "@/lib/supabase/client"
import { Badge } from "@/components/ui/badge"
import { formatSmartET } from "@/lib/format-time"

interface LiveDetails {
  period?: number
  detail?: string
  shortDetail?: string
  homeScore?: string
  awayScore?: string
  homeTeam?: string
  awayTeam?: string
  displayClock?: string
}

interface Event {
  id: string
  title: string
  category: string
  subcategory: string | null
  starts_at: string
  status: "scheduled" | "open" | "live" | "ended"
  live_details?: LiveDetails | null
}

interface EventInfoProps {
  event: Event
}

// ── Sport-specific scoreboard components ──────────────────────────────────

function BaseballScoreboard({ d, title }: { d: LiveDetails; title: string }) {
  return (
    <div className="flex items-center gap-6">
      <div className="flex items-center gap-3">
        <span className="text-2xl font-black tabular-nums">
          {d.awayScore ?? "0"}
        </span>
        <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
          {d.awayTeam}
        </span>
        <span className="text-muted-foreground font-light mx-1">vs</span>
        <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
          {d.homeTeam}
        </span>
        <span className="text-2xl font-black tabular-nums">
          {d.homeScore ?? "0"}
        </span>
      </div>
      {d.shortDetail || d.detail ? (
        <div className="flex items-center gap-1.5 bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="h-2 w-2 rounded-full bg-live animate-pulse" />
          <span className="text-sm font-semibold text-live">
            {d.shortDetail || d.detail}
          </span>
        </div>
      ) : null}
    </div>
  )
}

function BasketballScoreboard({ d }: { d: LiveDetails }) {
  const qLabel = d.period ? `Q${d.period}` : ""
  return (
    <div className="flex items-center gap-6">
      <div className="flex items-center gap-3">
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.awayTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.awayScore ?? "0"}</div>
        </div>
        <div className="text-muted-foreground text-xl font-light px-2">-</div>
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.homeTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.homeScore ?? "0"}</div>
        </div>
      </div>
      {(qLabel || d.displayClock) && (
        <div className="flex flex-col items-center bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="text-xs text-muted-foreground font-medium">{qLabel}</span>
          {d.displayClock && (
            <span className="text-lg font-black tabular-nums text-live leading-none">{d.displayClock}</span>
          )}
        </div>
      )}
    </div>
  )
}

function FootballScoreboard({ d }: { d: LiveDetails }) {
  const qLabel = d.period ? `Q${d.period}` : ""
  return (
    <div className="flex items-center gap-6">
      <div className="flex items-center gap-3">
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.awayTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.awayScore ?? "0"}</div>
        </div>
        <div className="text-muted-foreground text-xl font-light px-2">-</div>
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.homeTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.homeScore ?? "0"}</div>
        </div>
      </div>
      {(qLabel || d.displayClock) && (
        <div className="flex flex-col items-center bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="text-xs text-muted-foreground font-medium">{qLabel}</span>
          {d.displayClock && (
            <span className="text-lg font-black tabular-nums text-live leading-none">{d.displayClock}</span>
          )}
        </div>
      )}
    </div>
  )
}

function HockeyScoreboard({ d }: { d: LiveDetails }) {
  const pLabel = d.period ? `P${d.period}` : ""
  return (
    <div className="flex items-center gap-6">
      <div className="flex items-center gap-3">
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.awayTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.awayScore ?? "0"}</div>
        </div>
        <div className="text-muted-foreground text-xl font-light px-2">-</div>
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.homeTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.homeScore ?? "0"}</div>
        </div>
      </div>
      {(pLabel || d.displayClock) && (
        <div className="flex flex-col items-center bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="text-xs text-muted-foreground font-medium">{pLabel}</span>
          {d.displayClock && (
            <span className="text-lg font-black tabular-nums text-live leading-none">{d.displayClock}</span>
          )}
        </div>
      )}
    </div>
  )
}

function SoccerScoreboard({ d }: { d: LiveDetails }) {
  return (
    <div className="flex items-center gap-6">
      <div className="flex items-center gap-3">
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.awayTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.awayScore ?? "0"}</div>
        </div>
        <div className="text-muted-foreground text-xl font-light px-2">-</div>
        <div className="text-center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-0.5">{d.homeTeam}</div>
          <div className="text-3xl font-black tabular-nums">{d.homeScore ?? "0"}</div>
        </div>
      </div>
      {d.displayClock && (
        <div className="flex items-center gap-1.5 bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="h-2 w-2 rounded-full bg-live animate-pulse" />
          <span className="text-sm font-bold text-live">{d.displayClock}&apos;</span>
        </div>
      )}
    </div>
  )
}

function GenericScoreboard({ d }: { d: LiveDetails }) {
  return (
    <div className="flex items-center gap-4">
      {d.awayTeam && d.homeTeam && (
        <div className="flex items-center gap-3">
          <span className="text-2xl font-black tabular-nums">{d.awayScore ?? "0"}</span>
          <span className="text-sm text-muted-foreground font-semibold">{d.awayTeam}</span>
          <span className="text-muted-foreground">-</span>
          <span className="text-sm text-muted-foreground font-semibold">{d.homeTeam}</span>
          <span className="text-2xl font-black tabular-nums">{d.homeScore ?? "0"}</span>
        </div>
      )}
      {(d.shortDetail || d.detail) && (
        <div className="flex items-center gap-1.5 bg-live/10 border border-live/20 rounded-lg px-3 py-1.5">
          <span className="h-2 w-2 rounded-full bg-live animate-pulse" />
          <span className="text-sm font-semibold text-live">{d.shortDetail || d.detail}</span>
        </div>
      )}
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────────────────────

export function EventInfo({ event: initialEvent }: EventInfoProps) {
  const [event, setEvent] = useState<Event>(initialEvent)
  const supabase = createClient()

  const fetchLatest = useCallback(async () => {
    const { data } = await supabase
      .from("events")
      .select("id, title, category, subcategory, starts_at, status, live_details")
      .eq("id", initialEvent.id)
      .single()
    if (data) setEvent(data as Event)
  }, [initialEvent.id, supabase])

  // Poll every 30s for live score/status updates
  useEffect(() => {
    if (initialEvent.status !== "live") return
    const interval = setInterval(fetchLatest, 30000)
    return () => clearInterval(interval)
  }, [initialEvent.status, fetchLatest])

  // Real-time subscription for instant updates
  useEffect(() => {
    const channel = supabase
      .channel(`event-info-${initialEvent.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "events", filter: `id=eq.${initialEvent.id}` },
        (payload) => {
          setEvent((prev) => ({ ...prev, ...(payload.new as Partial<Event>) }))
        }
      )
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [initialEvent.id, supabase])

  const statusConfig = {
    live: { label: "LIVE", className: "bg-live text-live-foreground animate-pulse" },
    open: { label: "Room Open", className: "bg-open text-open-foreground" },
    scheduled: { label: "Upcoming", className: "bg-muted text-muted-foreground" },
    ended: { label: "Ended", className: "bg-muted text-muted-foreground" },
  }

  const status = statusConfig[event.status]
  const d = event.live_details
  const isLiveWithDetails = event.status === "live" && d && (d.homeTeam || d.detail || d.shortDetail)

  function renderScoreboard(d: LiveDetails) {
    switch (event.category) {
      case "baseball":   return <BaseballScoreboard d={d} title={event.title} />
      case "basketball": return <BasketballScoreboard d={d} />
      case "football":   return <FootballScoreboard d={d} />
      case "hockey":     return <HockeyScoreboard d={d} />
      case "soccer":     return <SoccerScoreboard d={d} />
      default:           return <GenericScoreboard d={d} />
    }
  }

  return (
    <div className="bg-card rounded-xl border overflow-hidden">
      {/* Header row */}
      <div className="flex items-center justify-between px-4 py-3 border-b">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs font-semibold uppercase tracking-wide">
            {event.subcategory || event.category}
          </Badge>
          <Badge className={status.className}>{status.label}</Badge>
        </div>
        <span className="text-xs text-muted-foreground">
          {formatSmartET(new Date(event.starts_at))}
        </span>
      </div>

      {/* Title + live scoreboard */}
      <div className="px-4 py-3">
        <h1 className="text-lg font-bold leading-tight mb-2">{event.title}</h1>
        {isLiveWithDetails ? (
          renderScoreboard(d!)
        ) : event.status === "live" ? (
          <div className="flex items-center gap-2 text-sm text-live">
            <span className="h-2 w-2 rounded-full bg-live animate-pulse" />
            Game is underway
          </div>
        ) : null}
      </div>
    </div>
  )
}
