"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreVertical, Pencil, Trash2, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface Poll {
  id: string
  question: string
  options: string[]
  ends_at: string | null
  created_at: string
  user_id: string
  is_active?: boolean
}

interface PollVote {
  poll_id: string
  option_index: number
  user_id: string
}

interface PollsSidebarProps {
  eventId: string
  userId: string
}

export function PollsSidebar({ eventId, userId }: PollsSidebarProps) {
  const supabase = createClient()
  const [polls, setPolls] = useState<Poll[]>([])
  const [votes, setVotes] = useState<PollVote[]>([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newQuestion, setNewQuestion] = useState("")
  const [newOptions, setNewOptions] = useState(["", ""])
  const [creating, setCreating] = useState(false)
  const [userRole, setUserRole] = useState<string>("user")

  // Fetch user role
  useEffect(() => {
    async function fetchUserRole() {
      const { data } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", userId)
        .single()

      if (data?.role) {
        setUserRole(data.role)
      }
    }
    fetchUserRole()
  }, [userId, supabase])

  const isAdminOrMod = userRole === "admin" || userRole === "moderator"

  // Fetch polls and votes
  useEffect(() => {
    async function fetchPolls() {
      const { data: pollsData } = await supabase
        .from("polls")
        .select("*")
        .eq("event_id", eventId)
        .order("created_at", { ascending: false })

      if (pollsData) {
        setPolls(pollsData)

        // Fetch all votes for these polls
        const pollIds = pollsData.map((p) => p.id)
        if (pollIds.length > 0) {
          const { data: votesData } = await supabase
            .from("poll_votes")
            .select("poll_id, option_index, user_id")
            .in("poll_id", pollIds)

          if (votesData) {
            setVotes(votesData)
          }
        }
      }
    }

    fetchPolls()
  }, [eventId, supabase])

  // Subscribe to real-time updates
  useEffect(() => {
    const pollsChannel = supabase
      .channel(`polls:${eventId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "polls",
          filter: `event_id=eq.${eventId}`,
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            setPolls((prev) => [payload.new as Poll, ...prev])
          } else if (payload.eventType === "UPDATE") {
            setPolls((prev) =>
              prev.map((p) => (p.id === payload.new.id ? (payload.new as Poll) : p))
            )
          } else if (payload.eventType === "DELETE") {
            setPolls((prev) => prev.filter((p) => p.id !== payload.old.id))
          }
        }
      )
      .subscribe()

    const votesChannel = supabase
      .channel(`poll_votes:${eventId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "poll_votes",
        },
        (payload) => {
          const newVote = payload.new as PollVote
          if (polls.some((p) => p.id === newVote.poll_id)) {
            setVotes((prev) => [...prev, newVote])
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(pollsChannel)
      supabase.removeChannel(votesChannel)
    }
  }, [eventId, polls, supabase])

  async function handleCreatePoll(e: React.FormEvent) {
    e.preventDefault()
    if (!newQuestion.trim() || newOptions.filter((o) => o.trim()).length < 2) return

    setCreating(true)

    const { error } = await supabase.from("polls").insert({
      event_id: eventId,
      user_id: userId,
      question: newQuestion.trim(),
      options: newOptions.filter((o) => o.trim()),
      is_active: true,
    })

    if (!error) {
      setNewQuestion("")
      setNewOptions(["", ""])
      setShowCreateForm(false)
    }

    setCreating(false)
  }

  async function handleVote(pollId: string, optionIndex: number) {
    const existingVote = votes.find((v) => v.poll_id === pollId && v.user_id === userId)
    if (existingVote) return

    const optimisticVote: PollVote = {
      poll_id: pollId,
      option_index: optionIndex,
      user_id: userId,
    }
    setVotes((prev) => [...prev, optimisticVote])

    const { error } = await supabase.from("poll_votes").insert({
      poll_id: pollId,
      user_id: userId,
      option_index: optionIndex,
    })

    if (error) {
      setVotes((prev) =>
        prev.filter((v) => !(v.poll_id === pollId && v.user_id === userId))
      )
    }
  }

  async function handleDeletePoll(pollId: string) {
    const { error } = await supabase.from("polls").delete().eq("id", pollId)
    if (!error) {
      setPolls((prev) => prev.filter((p) => p.id !== pollId))
    }
  }

  async function handleClosePoll(pollId: string) {
    const { error } = await supabase
      .from("polls")
      .update({ is_active: false })
      .eq("id", pollId)
    if (!error) {
      setPolls((prev) =>
        prev.map((p) => (p.id === pollId ? { ...p, is_active: false } : p))
      )
    }
  }

  async function handleUpdatePoll(pollId: string, question: string, options: string[]) {
    const { error } = await supabase
      .from("polls")
      .update({ question, options })
      .eq("id", pollId)
    if (!error) {
      setPolls((prev) =>
        prev.map((p) => (p.id === pollId ? { ...p, question, options } : p))
      )
    }
  }

  function addOption() {
    if (newOptions.length < 6) {
      setNewOptions([...newOptions, ""])
    }
  }

  function updateOption(index: number, value: string) {
    const updated = [...newOptions]
    updated[index] = value
    setNewOptions(updated)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">Polls</h3>
          {isAdminOrMod && (
            <span className="text-xs text-primary font-medium">
              {userRole === "admin" ? "Admin" : "Moderator"}
            </span>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowCreateForm(!showCreateForm)}
        >
          {showCreateForm ? "Cancel" : "Create Poll"}
        </Button>
      </div>

      {showCreateForm && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">New Poll</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreatePoll} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="question">Question</Label>
                <Input
                  id="question"
                  placeholder="Who will win tonight?"
                  value={newQuestion}
                  onChange={(e) => setNewQuestion(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Options</Label>
                {newOptions.map((option, index) => (
                  <Input
                    key={index}
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => updateOption(index, e.target.value)}
                    required={index < 2}
                  />
                ))}
                {newOptions.length < 6 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={addOption}
                    className="w-full"
                  >
                    + Add Option
                  </Button>
                )}
              </div>
              <Button type="submit" className="w-full" disabled={creating}>
                {creating ? "Creating..." : "Create Poll"}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {polls.length === 0 && !showCreateForm && (
        <p className="text-sm text-muted-foreground text-center py-4">
          No polls yet. Create one to get predictions from the room!
        </p>
      )}

      {polls.map((poll) => (
        <PollCard
          key={poll.id}
          poll={poll}
          votes={votes.filter((v) => v.poll_id === poll.id)}
          userId={userId}
          isAdminOrMod={isAdminOrMod}
          onVote={handleVote}
          onDelete={handleDeletePoll}
          onClose={handleClosePoll}
          onUpdate={handleUpdatePoll}
        />
      ))}
    </div>
  )
}

interface PollCardProps {
  poll: Poll
  votes: PollVote[]
  userId: string
  isAdminOrMod: boolean
  onVote: (pollId: string, optionIndex: number) => void
  onDelete: (pollId: string) => void
  onClose: (pollId: string) => void
  onUpdate: (pollId: string, question: string, options: string[]) => void
}

function PollCard({
  poll,
  votes,
  userId,
  isAdminOrMod,
  onVote,
  onDelete,
  onClose,
  onUpdate,
}: PollCardProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editQuestion, setEditQuestion] = useState(poll.question)
  const [editOptions, setEditOptions] = useState(poll.options)

  const userVote = votes.find((v) => v.user_id === userId)
  const hasVoted = !!userVote
  const totalVotes = votes.length
  const canManage = isAdminOrMod || poll.user_id === userId
  const isActive = poll.is_active !== false

  function handleSaveEdit() {
    if (editQuestion.trim() && editOptions.filter((o) => o.trim()).length >= 2) {
      onUpdate(poll.id, editQuestion.trim(), editOptions.filter((o) => o.trim()))
      setIsEditing(false)
    }
  }

  function handleCancelEdit() {
    setEditQuestion(poll.question)
    setEditOptions(poll.options)
    setIsEditing(false)
  }

  if (isEditing) {
    return (
      <Card className="border-primary">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Edit Poll</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={editQuestion}
            onChange={(e) => setEditQuestion(e.target.value)}
            placeholder="Question"
          />
          {editOptions.map((option, index) => (
            <Input
              key={index}
              value={option}
              onChange={(e) => {
                const updated = [...editOptions]
                updated[index] = e.target.value
                setEditOptions(updated)
              }}
              placeholder={`Option ${index + 1}`}
            />
          ))}
          <div className="flex gap-2">
            <Button size="sm" onClick={handleSaveEdit} className="flex-1">
              Save
            </Button>
            <Button size="sm" variant="outline" onClick={handleCancelEdit} className="flex-1">
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={cn(!isActive && "opacity-60")}>
      <CardContent className="pt-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <p className="font-medium">{poll.question}</p>
            {!isActive && (
              <span className="text-xs text-muted-foreground">(Closed)</span>
            )}
          </div>
          {canManage && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsEditing(true)}>
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit Poll
                </DropdownMenuItem>
                {isActive && (
                  <DropdownMenuItem onClick={() => onClose(poll.id)}>
                    <XCircle className="mr-2 h-4 w-4" />
                    Close Poll
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  onClick={() => onDelete(poll.id)}
                  className="text-destructive"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Poll
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        <div className="space-y-2">
          {poll.options.map((option, index) => {
            const optionVotes = votes.filter((v) => v.option_index === index).length
            const percentage = totalVotes > 0 ? (optionVotes / totalVotes) * 100 : 0
            const isSelected = userVote?.option_index === index

            return (
              <button
                key={index}
                onClick={() => !hasVoted && isActive && onVote(poll.id, index)}
                disabled={hasVoted || !isActive}
                className={cn(
                  "w-full text-left rounded-lg border p-3 transition-colors",
                  hasVoted || !isActive
                    ? isSelected
                      ? "border-primary bg-primary/5"
                      : "border-border"
                    : "hover:border-primary hover:bg-primary/5 cursor-pointer"
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{option}</span>
                  {(hasVoted || !isActive) && (
                    <span className="text-sm text-muted-foreground">
                      {optionVotes} ({percentage.toFixed(0)}%)
                    </span>
                  )}
                </div>
                {(hasVoted || !isActive) && (
                  <Progress value={percentage} className="h-1.5" />
                )}
              </button>
            )
          })}
        </div>
        <p className="text-xs text-muted-foreground mt-3">
          {totalVotes} vote{totalVotes !== 1 ? "s" : ""}
        </p>
      </CardContent>
    </Card>
  )
}
