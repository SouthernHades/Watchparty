"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChatMessage } from "./chat-message"
import { EmojiPicker } from "./emoji-picker"
import { Spinner } from "@/components/ui/spinner"

interface Message {
  id: string
  content: string
  created_at: string
  user_id: string
  profiles: {
    display_name: string
  } | null
}

interface ChatRoomProps {
  eventId: string
  userId: string
  userDisplayName: string
}

export function ChatRoom({ eventId, userId, userDisplayName }: ChatRoomProps) {
  const supabase = createClient()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  // Fetch initial messages
  useEffect(() => {
    async function fetchMessages() {
      console.log("[v0] Fetching messages for event:", eventId)
      const { data, error } = await supabase
        .from("messages")
        .select("id, content, created_at, user_id, event_id")
        .eq("event_id", eventId)
        .order("created_at", { ascending: true })
        .limit(100)

      console.log("[v0] Fetch result:", { data, error })
      
      if (error) {
        console.error("[v0] Error fetching messages:", error)
      } else if (data) {
        // Fetch user profiles separately
        const userIds = [...new Set(data.map((m) => m.user_id))]
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, display_name")
          .in("id", userIds)

        const profileMap = new Map(profiles?.map((p) => [p.id, p.display_name]) || [])

        const messagesWithProfiles = data.map((msg) => ({
          id: msg.id,
          content: msg.content,
          created_at: msg.created_at,
          user_id: msg.user_id,
          profiles: {
            display_name: profileMap.get(msg.user_id) || "Anonymous",
          },
        }))

        console.log("[v0] Messages loaded:", messagesWithProfiles.length)
        setMessages(messagesWithProfiles as Message[])
      }
      setLoading(false)
    }

    fetchMessages()
  }, [eventId, supabase])

  // Subscribe to new messages
  useEffect(() => {
    const channel = supabase
      .channel(`messages:${eventId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `event_id=eq.${eventId}`,
        },
        async (payload) => {
          // Fetch the profile for the new message
          const { data: profile } = await supabase
            .from("profiles")
            .select("display_name")
            .eq("id", payload.new.user_id)
            .single()

          const newMsg: Message = {
            id: payload.new.id,
            content: payload.new.content,
            created_at: payload.new.created_at,
            user_id: payload.new.user_id,
            profiles: profile,
          }

          setMessages((prev) => {
            // Check if message already exists (could be optimistic update or duplicate)
            const exists = prev.some(
              (m) => m.id === newMsg.id || 
              (m.id.startsWith("temp-") && m.content === newMsg.content && m.user_id === newMsg.user_id)
            )
            
            if (exists) {
              // Replace temp message with real one
              return prev.map((m) =>
                m.id.startsWith("temp-") && m.content === newMsg.content && m.user_id === newMsg.user_id
                  ? newMsg
                  : m
              )
            }
            
            return [...prev, newMsg]
          })
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [eventId, supabase])

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  async function handleSendMessage(e: React.FormEvent) {
    e.preventDefault()
    if (!newMessage.trim() || sending) return

    setSending(true)
    const messageContent = newMessage.trim()
    setNewMessage("")

    // Optimistic update
    const optimisticMessage: Message = {
      id: `temp-${Date.now()}`,
      content: messageContent,
      created_at: new Date().toISOString(),
      user_id: userId,
      profiles: { display_name: userDisplayName },
    }
    setMessages((prev) => [...prev, optimisticMessage])

    const { error } = await supabase.from("messages").insert({
      event_id: eventId,
      user_id: userId,
      content: messageContent,
    })

    if (error) {
      // Remove optimistic message on error
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMessage.id))
      setNewMessage(messageContent)
    }

    setSending(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-card rounded-xl border">
        <Spinner className="h-8 w-8" />
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-card rounded-xl border">
      {/* Messages */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-3"
      >
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <p>No messages yet. Be the first to say something!</p>
          </div>
        ) : (
          messages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message}
              isOwn={message.user_id === userId}
              userId={userId}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSendMessage} className="p-4 border-t">
        <div className="flex gap-2 items-center">
          <EmojiPicker 
            onEmojiSelect={(emoji) => setNewMessage((prev) => prev + emoji)} 
          />
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            disabled={sending}
            className="flex-1"
            maxLength={500}
          />
          <Button type="submit" disabled={!newMessage.trim() || sending}>
            Send
          </Button>
        </div>
      </form>
    </div>
  )
}
