import Link from "next/link"
import { formatDistanceToNow, isPast } from "date-fns"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatSmartET, formatLiveStatus } from "@/lib/format-time"

interface LiveDetails {
  period?: number
  detail?: string
  shortDetail?: string
  homeScore?: string
  awayScore?: string
  homeTeam?: string
  awayTeam?: string
  displayClock?: string
}

interface Event {
  id: string
  title: string
  category: string
  subcategory: string | null
  starts_at: string
  status: "scheduled" | "open" | "live" | "ended"
  image_url: string | null
  live_details?: LiveDetails | null
}

interface EventCardProps {
  event: Event
}

export function EventCard({ event }: EventCardProps) {
  const startsAt = new Date(event.starts_at)
  
  const statusConfig = {
    live: { label: "LIVE", className: "bg-live text-live-foreground animate-pulse" },
    open: { label: "Open", className: "bg-open text-open-foreground" },
    scheduled: { label: formatDistanceToNow(startsAt, { addSuffix: true }), className: "bg-muted text-muted-foreground" },
    ended: { label: "Ended", className: "bg-muted text-muted-foreground" },
  }

  const status = statusConfig[event.status]
  const canJoin = event.status === "live" || event.status === "open"
  
  // Get live game status (inning, quarter, score, etc.)
  const liveStatus = event.status === "live" 
    ? formatLiveStatus(event.live_details || null, event.category)
    : null

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                {event.subcategory || event.category}
              </Badge>
              <Badge className={status.className}>
                {status.label}
              </Badge>
            </div>
            <h3 className="font-semibold leading-tight line-clamp-2 mt-2">
              {event.title}
            </h3>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-3 space-y-2">
        {/* Show live game status (inning, score, etc.) for live events */}
        {liveStatus && (
          <div className="flex items-center text-sm font-medium text-live">
            <svg className="mr-1.5 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="4" />
            </svg>
            {liveStatus}
          </div>
        )}
        
        {/* Show time for non-live events */}
        {!liveStatus && (
          <div className="flex items-center text-sm text-muted-foreground">
            <svg className="mr-1.5 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            {formatSmartET(startsAt)}
          </div>
        )}
      </CardContent>
      <CardFooter>
        {canJoin ? (
          <Button className="w-full" asChild>
            <Link href={`/events/${event.id}`}>
              {event.status === "live" ? "Join Live Chat" : "Enter Room"}
            </Link>
          </Button>
        ) : event.status === "scheduled" ? (
          <Button variant="outline" className="w-full" disabled>
            Opens {formatDistanceToNow(new Date(event.starts_at), { addSuffix: true })}
          </Button>
        ) : (
          <Button variant="secondary" className="w-full" asChild>
            <Link href={`/events/${event.id}`}>View Recap</Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
