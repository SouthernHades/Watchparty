"use client"

import { Button } from "@/components/ui/button"

interface EventFiltersProps {
  currentCategory?: string
  onCategoryChange?: (category: string) => void
}

const statuses = [
  { value: "", label: "All Sports" },
]

const categories = [
  { value: "", label: "All" },
  { value: "basketball", label: "Basketball" },
  { value: "baseball", label: "Baseball" },
  { value: "football", label: "Football" },
  { value: "ufc", label: "UFC" },
  { value: "soccer", label: "Soccer" },
  { value: "golf", label: "Golf" },
  { value: "hockey", label: "Hockey" },
  { value: "reality", label: "Reality TV" },
]

export function EventFilters({ currentCategory = "", onCategoryChange }: EventFiltersProps) {
  return (
    <div className="flex flex-wrap gap-2 mb-8">
      {categories.map((category) => (
        <Button
          key={category.value}
          variant={currentCategory === category.value ? "default" : "outline"}
          size="sm"
          onClick={() => onCategoryChange?.(category.value)}
        >
          {category.label}
        </Button>
      ))}
    </div>
  )
}
