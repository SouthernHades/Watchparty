"use client"

import { useState, useEffect, useCallback } from "react"
import { createClient } from "@/lib/supabase/client"
import { Header } from "@/components/header"
import { EventCard } from "@/components/event-card"
import { EventFilters } from "@/components/event-filters"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Spinner } from "@/components/ui/spinner"

interface Event {
  id: string
  title: string
  category: string
  subcategory: string | null
  starts_at: string
  room_opens_at: string
  status: "scheduled" | "open" | "live" | "ended"
  image_url: string | null
}

export default function EventsPage() {
  const supabase = createClient()
  const [events, setEvents] = useState<Event[]>([])
  const [selectedCategory, setSelectedCategory] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [lastSyncTime, setLastSyncTime] = useState<string>("Loading...")
  const [syncInProgress, setSyncInProgress] = useState(false)

  // Fetch events from database
  const fetchEvents = useCallback(async () => {
    try {
      let query = supabase
        .from("events")
        .select("*")
        .order("starts_at", { ascending: true })
        .limit(100)

      if (selectedCategory) {
        query = query.eq("category", selectedCategory)
      }

      const { data, error } = await query

      if (error) {
        console.error("Error fetching events:", error)
        return
      }

      setEvents(data || [])
    } catch (error) {
      console.error("Error fetching events:", error)
    }
  }, [selectedCategory, supabase])

  // Trigger sports sync cron job
  const triggerSportsSync = useCallback(async () => {
    setSyncInProgress(true)
    try {
      const response = await fetch("/api/cron/sync-sports", {
        method: "GET",
      })

      if (response.ok) {
        const now = new Date()
        setLastSyncTime(now.toLocaleTimeString([], { 
          hour: "2-digit", 
          minute: "2-digit",
          second: "2-digit"
        }))
        
        // Wait a bit for database to update
        await new Promise(resolve => setTimeout(resolve, 500))
        await fetchEvents()
      }
    } catch (error) {
      console.error("Error syncing sports:", error)
    } finally {
      setSyncInProgress(false)
    }
  }, [fetchEvents])

  // Initial load and sync
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      await triggerSportsSync()
      setIsLoading(false)
    }
    loadData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  
  // Refetch when category changes
  useEffect(() => {
    fetchEvents()
  }, [selectedCategory, fetchEvents])

  // Auto-sync every 30 seconds to keep events fresh
  useEffect(() => {
    const syncInterval = setInterval(() => {
      triggerSportsSync()
    }, 30000) // 30 seconds

    return () => {
      clearInterval(syncInterval)
    }
  }, [triggerSportsSync])

  // Subscribe to real-time database changes (Supabase v2 syntax)
  useEffect(() => {
    const channel = supabase
      .channel("events-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "events" },
        () => {
          fetchEvents()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchEvents, supabase])

  const groupedByStatus = {
    live: events.filter((e) => e.status === "live"),
    open: events.filter((e) => e.status === "open"),
    scheduled: events.filter((e) => e.status === "scheduled"),
  }

  const allEvents = [...groupedByStatus.live, ...groupedByStatus.open, ...groupedByStatus.scheduled]

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="container max-w-6xl py-8">
          <div className="mb-8">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">Live Events</h1>
                <p className="text-muted-foreground">
                  Join chat rooms for sports, reality TV, and more
                </p>
              </div>
              <div className="text-right text-sm">
                <p className="text-muted-foreground">
                  <span className="font-semibold">Last synced:</span> {lastSyncTime}
                </p>
                <p className="text-xs text-muted-foreground mt-1 flex items-center justify-end gap-1">
                  {syncInProgress && (
                    <>
                      <Spinner className="h-3 w-3" />
                      Syncing...
                    </>
                  )}
                  {!syncInProgress && "Auto-sync every 60s"}
                </p>
              </div>
            </div>

            <EventFilters
              currentCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
            />
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <div className="text-center">
                <Spinner className="h-8 w-8 mx-auto mb-4" />
                <p className="text-muted-foreground">Loading events from ESPN...</p>
              </div>
            </div>
          ) : (
            <Tabs defaultValue="live" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="live" className="flex items-center gap-2">
                  <span className="flex h-2 w-2 rounded-full bg-live animate-pulse" />
                  Live ({groupedByStatus.live.length})
                </TabsTrigger>
                <TabsTrigger value="open">
                  Open ({groupedByStatus.open.length})
                </TabsTrigger>
                <TabsTrigger value="scheduled">
                  Upcoming ({groupedByStatus.scheduled.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="live" className="mt-6">
                {groupedByStatus.live.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {groupedByStatus.live.map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">No live events right now</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="open" className="mt-6">
                {groupedByStatus.open.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {groupedByStatus.open.map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">No open rooms right now</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="scheduled" className="mt-6">
                {groupedByStatus.scheduled.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {groupedByStatus.scheduled.map((event) => (
                      <EventCard key={event.id} event={event} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">No upcoming events</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}

          {!isLoading && allEvents.length > 0 && (
            <div className="mt-8 text-center text-xs text-muted-foreground">
              <p>Showing {allEvents.length} events • Last updated: {lastSyncTime}</p>
            </div>
          )}
        </div>
      </main>
    </>
  )
}
