import { notFound, redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { ChatRoom } from "@/components/chat/chat-room"
import { EventInfo } from "@/components/chat/event-info"
import { PollsSidebar } from "@/components/chat/polls-sidebar"
import { format } from "date-fns"

interface EventPageProps {
  params: Promise<{ id: string }>
}

export default async function EventPage({ params }: EventPageProps) {
  const { id } = await params
  const supabase = await createClient()
  
  // Get current user
  const { data: { user } } = await supabase.auth.getUser()
  
  // Fetch event
  const { data: event, error } = await supabase
    .from("events")
    .select("*")
    .eq("id", id)
    .single()
  
  if (error || !event) {
    notFound()
  }
  
  // Redirect to login if not authenticated
  if (!user) {
    redirect(`/auth/login?redirect=/events/${id}`)
  }
  
  // Fetch user profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()
  
  const canChat = event.status === "live" || event.status === "open"
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container py-6">
        <div className="grid lg:grid-cols-[1fr_340px] gap-6 h-[calc(100vh-8rem)]">
          {/* Main Chat Area */}
          <div className="flex flex-col min-h-0">
            <EventInfo event={event} />
            <div className="flex-1 mt-4 min-h-0">
              {canChat ? (
                <ChatRoom 
                  eventId={event.id} 
                  userId={user.id}
                  userDisplayName={profile?.display_name || user.email?.split("@")[0] || "Anonymous"}
                />
              ) : (
                <div className="flex items-center justify-center h-full bg-muted/50 rounded-xl">
                  <div className="text-center p-6">
                    {event.status === "scheduled" ? (
                      <>
                        <p className="text-lg font-medium">Chat opens soon</p>
                        <p className="text-muted-foreground mt-1">
                          Room opens {format(new Date(event.room_opens_at), "MMM d 'at' h:mm a")}
                        </p>
                      </>
                    ) : (
                      <>
                        <p className="text-lg font-medium">This event has ended</p>
                        <p className="text-muted-foreground mt-1">
                          Chat is now closed
                        </p>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Sidebar - Polls */}
          {canChat && (
            <aside className="hidden lg:block">
              <div className="sticky top-24 p-4 bg-card rounded-xl border max-h-[calc(100vh-8rem)] overflow-y-auto">
                <PollsSidebar eventId={event.id} userId={user.id} />
              </div>
            </aside>
          )}
        </div>
      </main>
    </div>
  )
}
