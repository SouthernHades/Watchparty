import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { createClient } from "@/lib/supabase/server"
import { EventCard } from "@/components/event-card"

export default async function HomePage() {
  const supabase = await createClient()
  
  // Fetch upcoming and live events
  const { data: events } = await supabase
    .from("events")
    .select("*")
    .in("status", ["live", "open", "scheduled"])
    .order("starts_at", { ascending: true })
    .limit(6)

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-24 md:py-32">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
          <div className="container relative">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl text-balance">
                Watch Together,{" "}
                <span className="text-primary">React Together</span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
                Join thousands of fans in real-time chat rooms for live sports, reality TV, and entertainment events. 
                Share reactions, make predictions, and experience every moment with your community.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" asChild className="w-full sm:w-auto">
                  <Link href="/events">Browse Live Events</Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="w-full sm:w-auto">
                  <Link href="/auth/sign-up">Create Free Account</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 md:py-24 bg-muted/50">
          <div className="container">
            <h2 className="text-2xl font-bold text-center mb-12">
              Everything You Need for the Ultimate Watch Party
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                title="Real-Time Chat"
                description="Instant messages with no delay. React to big plays and shocking eliminations the moment they happen."
                icon={
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                }
              />
              <FeatureCard
                title="Live Polls & Predictions"
                description="Vote on who gets eliminated, predict final scores, and see how your picks stack up against the community."
                icon={
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                }
              />
              <FeatureCard
                title="Auto-Synced Events"
                description="Never miss a game. Rooms open automatically 10 minutes before kickoff for all major sports."
                icon={
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                }
              />
            </div>
          </div>
        </section>

        {/* Live Events Preview */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-bold">Happening Now</h2>
                <p className="text-muted-foreground mt-1">Jump into an active watch party</p>
              </div>
              <Button variant="outline" asChild>
                <Link href="/events">View All Events</Link>
              </Button>
            </div>
            
            {events && events.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {events.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-muted/50 rounded-xl">
                <p className="text-muted-foreground">No live events right now. Check back soon!</p>
                <Button variant="link" asChild className="mt-2">
                  <Link href="/events">Browse upcoming events</Link>
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-24 bg-primary text-primary-foreground">
          <div className="container text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Join the Party?</h2>
            <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
              Sign up for free and start chatting with fans during live events.
            </p>
            <Button size="lg" variant="secondary" asChild>
              <Link href="/auth/sign-up">Get Started Free</Link>
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-primary text-primary-foreground font-bold text-sm">
              W
            </div>
            <span className="font-semibold">WatchParty</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Watch together, react together.
          </p>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ 
  title, 
  description, 
  icon 
}: { 
  title: string
  description: string
  icon: React.ReactNode 
}) {
  return (
    <div className="flex flex-col items-center text-center p-6 rounded-xl bg-background border">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary mb-4">
        {icon}
      </div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm">{description}</p>
    </div>
  )
}
