import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"
import { subMinutes, addDays, format, isBefore, isAfter, parseISO } from "date-fns"

// Runs every 5 minutes via Vercel cron to keep event statuses accurate (no date-fns-tz needed)
// and auto-open rooms exactly 10 minutes before game time.

const LEAGUES = [
  // Football
  { id: "nfl",  name: "NFL",  sport: "football",   category: "sports", sportCategory: "football" },
  { id: "college-football", name: "NCAAF", sport: "football", category: "sports", sportCategory: "football" },
  // Basketball
  { id: "nba",  name: "NBA",  sport: "basketball", category: "sports", sportCategory: "basketball" },
  { id: "wnba", name: "WNBA", sport: "basketball", category: "sports", sportCategory: "basketball" },
  { id: "mens-college-basketball", name: "NCAAM", sport: "basketball", category: "sports", sportCategory: "basketball" },
  // Baseball
  { id: "mlb",  name: "MLB",  sport: "baseball",   category: "sports", sportCategory: "baseball" },
  // Hockey
  { id: "nhl",  name: "NHL",  sport: "hockey",     category: "sports", sportCategory: "hockey" },
  // UFC/MMA
  { id: "ufc",  name: "UFC",  sport: "mma",        category: "sports", sportCategory: "ufc" },
  // Soccer
  { id: "usa.1", name: "MLS",  sport: "soccer",   category: "sports", sportCategory: "soccer" },
  { id: "eng.1", name: "EPL",  sport: "soccer",   category: "sports", sportCategory: "soccer" },
  { id: "uefa.champions", name: "Champions League", sport: "soccer", category: "sports", sportCategory: "soccer" },
  // Golf
  { id: "pga",  name: "PGA Tour",  sport: "golf",   category: "sports", sportCategory: "golf" },
]

// ESPN scoreboard supports a date range: ?dates=YYYYMMDD-YYYYMMDD
function buildScoreboardUrl(sport: string, league: string, fromDate: Date, toDate: Date) {
  const from = format(fromDate, "yyyyMMdd")
  const to   = format(toDate,   "yyyyMMdd")
  return `https://site.api.espn.com/apis/site/v2/sports/${sport}/${league}/scoreboard?dates=${from}-${to}&limit=100`
}

interface ESPNCompetitor {
  homeAway: "home" | "away"
  team: { displayName: string; abbreviation: string }
}

interface ESPNEvent {
  id: string
  date: string
  name: string
  status: { 
    type: { name: string; completed: boolean; detail?: string; shortDetail?: string }
    period?: number
    displayClock?: string
  }
  competitions: Array<{
    competitors: ESPNCompetitor[]
  }>
}

interface LiveDetails {
  period?: number          // Inning, quarter, period, round, etc.
  displayClock?: string    // "3:45" remaining in quarter, etc.
  detail?: string          // "Bottom 8th", "4th Quarter", etc.
  shortDetail?: string     // "Bot 8th", "Q4", etc.
  homeScore?: string
  awayScore?: string
  homeTeam?: string
  awayTeam?: string
}

function buildLiveDetails(event: ESPNEvent): LiveDetails | null {
  const competitors = event.competitions?.[0]?.competitors ?? []
  const home = competitors.find((c) => c.homeAway === "home")
  const away = competitors.find((c) => c.homeAway === "away")
  
  // Only include details for in-progress games
  const espnStatus = event.status.type.name
  if (espnStatus !== "STATUS_IN_PROGRESS" && espnStatus !== "STATUS_HALFTIME" && espnStatus !== "STATUS_END_PERIOD") {
    return null
  }

  return {
    period: event.status.period,
    displayClock: event.status.displayClock,
    detail: event.status.type.detail,
    shortDetail: event.status.type.shortDetail,
    homeScore: (home as any)?.score,
    awayScore: (away as any)?.score,
    homeTeam: home?.team?.abbreviation,
    awayTeam: away?.team?.abbreviation,
  }
}

interface ESPNResponse {
  events?: ESPNEvent[]
}

function buildTitle(event: ESPNEvent): string {
  const competitors = event.competitions?.[0]?.competitors ?? []
  if (competitors.length === 2) {
    const away = competitors.find((c) => c.homeAway === "away")
    const home = competitors.find((c) => c.homeAway === "home")
    if (away && home) {
      return `${away.team.displayName} at ${home.team.displayName}`
    }
  }
  // Fallback to ESPN's own name field
  return event.name
}

function resolveStatus(
  event: ESPNEvent,
  startsAt: Date,
  roomOpensAt: Date,
  now: Date
): "scheduled" | "open" | "live" | "ended" {
  const espnStatus = event.status.type.name

  // Always trust ESPN's completion flag first
  if (espnStatus === "STATUS_FINAL" || espnStatus === "STATUS_FULL_TIME" || event.status.type.completed) return "ended"
  if (espnStatus === "STATUS_IN_PROGRESS" || espnStatus === "STATUS_HALFTIME" || espnStatus === "STATUS_END_PERIOD") return "live"

  // If start time was more than 4 hours ago and not marked in-progress, assume ended
  const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000)
  if (isBefore(startsAt, fourHoursAgo)) return "ended"

  // Room opens 10 min before start
  if (isBefore(roomOpensAt, now) && isAfter(startsAt, now)) return "open"
  if (isBefore(now, roomOpensAt)) return "scheduled"

  // Start time just passed but ESPN hasn't updated yet — treat as live
  return "live"
}

export async function GET(request: Request) {
  // Protect the endpoint in production
  const authHeader = request.headers.get("authorization")
  if (process.env.NODE_ENV === "production") {
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!supabaseUrl || !supabaseServiceKey) {
    return NextResponse.json({ error: "Missing Supabase env vars" }, { status: 500 })
  }

  // Service role key bypasses RLS — required for server-side upserts
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  const now      = new Date()
  const nextWeek = addDays(now, 7)
  const summary: { league: string; fetched: number; upserted: number; errors: string[] }[] = []

  // ─── 1. Fetch & upsert upcoming/live events from ESPN ─────────────────────
  for (const league of LEAGUES) {
    const errors: string[] = []
    let fetched  = 0
    let upserted = 0

    try {
      const url = buildScoreboardUrl(league.sport, league.id, now, nextWeek)
      const res = await fetch(url, { next: { revalidate: 0 } })

      if (!res.ok) {
        summary.push({ league: league.name, fetched: 0, upserted: 0, errors: [`HTTP ${res.status}`] })
        continue
      }

      const data: ESPNResponse = await res.json()
      const events = data.events ?? []
      fetched = events.length

      for (const event of events) {
        const startsAt    = parseISO(event.date)
        const roomOpensAt = subMinutes(startsAt, 10)
        const status      = resolveStatus(event, startsAt, roomOpensAt, now)
        const title       = buildTitle(event)
        const liveDetails = buildLiveDetails(event)

        const { error } = await supabase.from("events").upsert(
          {
            external_id:   `espn_${league.id}_${event.id}`,
            source:        "espn",
            title,
            category:      league.sportCategory, // basketball, baseball, ufc, soccer, golf, football
            subcategory:   league.name,          // NBA, MLB, UFC, MLS, PGA Tour, etc.
            starts_at:     startsAt.toISOString(),
            room_opens_at: roomOpensAt.toISOString(),
            status,
            live_details:  liveDetails,
          },
          { onConflict: "external_id", ignoreDuplicates: false }
        )

        if (error) {
          errors.push(error.message)
        } else {
          upserted++
        }
      }
    } catch (err) {
      errors.push(err instanceof Error ? err.message : String(err))
    }

    summary.push({ league: league.name, fetched, upserted, errors })
  }

  // ─── 2. Sync manual reality TV shows (Survivor, Bachelor, etc.) ────────────
  // These are scheduled for specific times — add them as manual events
  const manualShows = [
    // Survivor - Wednesdays at 8 PM ET (we'll create upcoming episodes)
    {
      title: "Survivor Season 47",
      subcategory: "Survivor",
      dayOfWeek: 3, // Wednesday (0=Sunday, 3=Wednesday)
      time: "20:00", // 8 PM ET
    },
    // Bachelor/Bachelorette - Mondays at 8 PM ET
    {
      title: "The Bachelor Season 29",
      subcategory: "Bachelor",
      dayOfWeek: 1, // Monday
      time: "20:00",
    },
  ]

  for (const show of manualShows) {
    try {
      // Find upcoming air dates for this show (next 10 instances)
      let checkDate = new Date(now)
      const airDates: Date[] = []

      for (let i = 0; i < 10 && airDates.length < 10; i++) {
        if (checkDate.getDay() === show.dayOfWeek && checkDate > now) {
          const [hours, minutes] = show.time.split(":").map(Number)
          
          // Create date with ET time (accounting for daylight saving)
          // Convert ET time to UTC by constructing as if it's UTC then adjusting
          const year = checkDate.getFullYear()
          const month = checkDate.getMonth()
          const day = checkDate.getDate()
          
          // Create as UTC initially
          const utcDate = new Date(Date.UTC(year, month, day, hours, minutes, 0))
          
          // Get the offset for Eastern Time on this date
          // Create a date string and use Intl.DateTimeFormat to get the offset
          const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/New_York',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
          })
          
          // The difference between ET and UTC varies (EST is -5, EDT is -4)
          // We need to find what offset applies on this date
          const testDate = new Date(year, month, day, hours, minutes, 0)
          const parts = formatter.formatToParts(testDate)
          const etYear = parseInt(parts.find(p => p.type === 'year')?.value || '0')
          const etMonth = parseInt(parts.find(p => p.type === 'month')?.value || '0') - 1
          const etDay = parseInt(parts.find(p => p.type === 'day')?.value || '0')
          const etHour = parseInt(parts.find(p => p.type === 'hour')?.value || '0')
          
          // Get UTC time of midnight ET on this date
          const midnightET = new Date(year, month, day, 0, 0, 0)
          const midnightUTC = new Date(midnightET.toLocaleString('en-US', { timeZone: 'UTC' }))
          const offsetMs = midnightET.getTime() - midnightUTC.getTime()
          
          // Convert ET time to UTC
          const episodeDate = new Date(testDate.getTime() - offsetMs)

          if (episodeDate > now) {
            airDates.push(episodeDate)
          }
        }
        checkDate.setDate(checkDate.getDate() + 1)
      }

      // Upsert each upcoming episode
      for (const airDate of airDates) {
        const roomOpensAt = subMinutes(airDate, 10)
        const status = resolveStatus(
          {
            id: "",
            date: airDate.toISOString(),
            name: show.title,
            status: { type: { name: "STATUS_SCHEDULED", completed: false } },
            competitions: [],
          },
          airDate,
          roomOpensAt,
          now
        )

        await supabase.from("events").upsert(
          {
            external_id:   `manual_${show.subcategory}_${airDate.getTime()}`,
            source:        "manual",
            title:         show.title,
            category:      "reality",
            subcategory:   show.subcategory,
            starts_at:     airDate.toISOString(),
            room_opens_at: roomOpensAt.toISOString(),
            status,
          },
          { onConflict: "external_id", ignoreDuplicates: false }
        )
      }
    } catch (err) {
      console.error(`Error syncing ${show.title}:`, err)
    }
  }

  // ─── 3. Status transitions for ALL events ─────────────────────────────────
  // scheduled → open  (room_opens_at has passed, game hasn't started yet)
  await supabase
    .from("events")
    .update({ status: "open" })
    .eq("status", "scheduled")
    .lte("room_opens_at", now.toISOString())
    .gt("starts_at", now.toISOString())

  // scheduled/open → live  (game start time has passed)
  await supabase
    .from("events")
    .update({ status: "live" })
    .in("status", ["scheduled", "open"])
    .lte("starts_at", now.toISOString())

  // live/open/scheduled → ended  (started more than 4 hours ago = definitely over)
  const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000)
  await supabase
    .from("events")
    .update({ status: "ended" })
    .in("status", ["live", "open", "scheduled"])
    .lt("starts_at", fourHoursAgo.toISOString())

  // ─── 4. Delete stale events older than 48 hours so they don't pile up ─────
  const twoDaysAgo = new Date(now.getTime() - 48 * 60 * 60 * 1000)
  await supabase
    .from("events")
    .delete()
    .lt("starts_at", twoDaysAgo.toISOString())

  return NextResponse.json({
    success:   true,
    timestamp: now.toISOString(),
    nextWeek:  nextWeek.toISOString(),
    summary,
  })
}
