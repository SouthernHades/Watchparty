import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"
import { addMinutes, addHours, subMinutes, addDays } from "date-fns"

// Seed endpoint to populate sample events for testing
// Only accessible in development

const SAMPLE_EVENTS = [
  // Live now
  { title: "Lakers vs Celtics", category: "sports", subcategory: "NBA", hoursOffset: -1, status: "live" },
  { title: "The Bachelor Season 28 Episode 5", category: "reality", subcategory: "Bachelor", hoursOffset: -0.5, status: "live" },
  
  // Room open (starting soon)
  { title: "49ers vs Cowboys", category: "sports", subcategory: "NFL", hoursOffset: 0.1, status: "open" },
  { title: "Survivor Season 47 Episode 10", category: "reality", subcategory: "Survivor", hoursOffset: 0.15, status: "open" },
  
  // Upcoming (scheduled)
  { title: "Yankees vs Red Sox", category: "sports", subcategory: "MLB", hoursOffset: 2, status: "scheduled" },
  { title: "Golden Knights vs Bruins", category: "sports", subcategory: "NHL", hoursOffset: 4, status: "scheduled" },
  { title: "The Voice Live Finale", category: "reality", subcategory: "The Voice", hoursOffset: 6, status: "scheduled" },
  { title: "Oscar Awards 2026", category: "awards", subcategory: "Oscars", hoursOffset: 24, status: "scheduled" },
  { title: "Heat vs Nuggets", category: "sports", subcategory: "NBA", hoursOffset: 48, status: "scheduled" },
  { title: "Love Island Episode 15", category: "reality", subcategory: "Love Island", hoursOffset: 72, status: "scheduled" },
]

export async function POST() {
  // Only allow in development
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Not available in production" }, { status: 403 })
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    return NextResponse.json({ error: "Missing Supabase credentials" }, { status: 500 })
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey)
  const now = new Date()

  const events = SAMPLE_EVENTS.map((event, index) => {
    const startsAt = addMinutes(now, event.hoursOffset * 60)
    const roomOpensAt = subMinutes(startsAt, 10)
    
    return {
      external_id: `seed_${index}_${Date.now()}`,
      source: "manual",
      title: event.title,
      category: event.category,
      subcategory: event.subcategory,
      starts_at: startsAt.toISOString(),
      room_opens_at: roomOpensAt.toISOString(),
      status: event.status,
    }
  })

  const { data, error } = await supabase.from("events").insert(events).select()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({
    success: true,
    message: `Seeded ${data.length} events`,
    events: data,
  })
}
