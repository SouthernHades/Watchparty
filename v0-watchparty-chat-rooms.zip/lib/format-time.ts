/**
 * Formats a date to Eastern Time with "ET" suffix
 * Handles both EST and EDT automatically
 */
export function formatToET(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  
  return d.toLocaleString("en-US", {
    timeZone: "America/New_York",
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }) + " ET"
}

/**
 * Formats just the time portion in Eastern Time
 */
export function formatTimeOnlyET(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  
  return d.toLocaleString("en-US", {
    timeZone: "America/New_York",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }) + " ET"
}

/**
 * Gets today's date string in Eastern Time (for comparison)
 */
export function getTodayET(): string {
  return new Date().toLocaleDateString("en-US", {
    timeZone: "America/New_York",
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

/**
 * Checks if a date is today in Eastern Time
 */
export function isTodayET(date: Date | string): boolean {
  const d = typeof date === "string" ? new Date(date) : date
  const dateString = d.toLocaleDateString("en-US", {
    timeZone: "America/New_York",
    month: "short",
    day: "numeric",
    year: "numeric",
  })
  return dateString === getTodayET()
}

/**
 * Formats a UTC date to the user's LOCAL timezone (not hardcoded ET)
 * Shows "Today at 3:30 PM" or "May 10 at 7:30 PM" with their local timezone
 */
export function formatSmartET(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  
  // Get user's local timezone without hardcoding ET
  const formatter = new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZoneName: "short",
  })
  
  const time = formatter.format(d)
  
  // Check if date is today by comparing in user's local timezone
  const today = new Date()
  const dateInLocal = new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    timeZone: undefined, // Use browser's local timezone
  }).format(d)
  
  const todayStr = new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(today)
  
  if (dateInLocal === todayStr) {
    return `Today at ${time}`
  }
  
  const dateStr = new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
  }).format(d)
  
  return `${dateStr} at ${time}`
}

/**
 * Format live game status for display
 * Shows inning/quarter/period with score
 */
export function formatLiveStatus(liveDetails: {
  period?: number
  detail?: string
  shortDetail?: string
  homeScore?: string
  awayScore?: string
  homeTeam?: string
  awayTeam?: string
  displayClock?: string
} | null, category: string): string | null {
  if (!liveDetails) return null
  
  const { detail, shortDetail, homeScore, awayScore, homeTeam, awayTeam, displayClock, period } = liveDetails
  
  // Build score string if available
  let scoreStr = ""
  if (awayScore !== undefined && homeScore !== undefined && awayTeam && homeTeam) {
    scoreStr = `${awayTeam} ${awayScore} - ${homeTeam} ${homeScore}`
  }
  
  // Use detail or shortDetail for period info
  const periodInfo = shortDetail || detail || ""
  
  if (periodInfo && scoreStr) {
    return `${periodInfo} | ${scoreStr}`
  }
  if (periodInfo) {
    return periodInfo
  }
  
  // Fallback based on category
  if (category === "baseball" && period) {
    const inningStr = `Inning ${period}`
    return scoreStr ? `${inningStr} | ${scoreStr}` : inningStr
  }
  if (category === "basketball" && period) {
    const qStr = `Q${period}${displayClock ? ` ${displayClock}` : ""}`
    return scoreStr ? `${qStr} | ${scoreStr}` : qStr
  }
  if (category === "football" && period) {
    const qStr = `Q${period}${displayClock ? ` ${displayClock}` : ""}`
    return scoreStr ? `${qStr} | ${scoreStr}` : qStr
  }
  if (category === "hockey" && period) {
    const pStr = `P${period}${displayClock ? ` ${displayClock}` : ""}`
    return scoreStr ? `${pStr} | ${scoreStr}` : pStr
  }
  if (category === "soccer" && displayClock) {
    return scoreStr ? `${displayClock}' | ${scoreStr}` : `${displayClock}'`
  }
  
  return scoreStr || null
}
